// lib/exemplo_main.dart
// EXEMPLO de como juntar tudo. Não precisa copiar inteiro: o que importa é
//   1) JustAudioBackground.init(...) antes do runApp (liga a notificação);
//   2) criar UM MusicController e passar o mesmo pra todas as telas;
//   3) colocar o MiniPlayer logo acima do menu de baixo.
// Adapte para as abas que você já tem (Início, Salas, COBRA CARDS...).

import 'package:flutter/material.dart';
import 'package:just_audio_background/just_audio_background.dart';
import 'games/guess_song_game.dart';
import 'games/memory_game.dart';
import 'screens/explore_screen.dart';
import 'screens/library_screen.dart';
import 'screens/player_screen.dart';
import 'services/music_controller.dart';
import 'widgets/ui_common.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await JustAudioBackground.init(
    androidNotificationChannelId: 'com.cobrasong.app.audio',
    androidNotificationChannelName: 'COBRASONG',
    androidNotificationOngoing: true,
  );
  runApp(const CobraApp());
}

class CobraApp extends StatelessWidget {
  const CobraApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'COBRASONG',
      debugShowCheckedModeBanner: false,
      theme: ThemeData.dark(useMaterial3: true).copyWith(
        scaffoldBackgroundColor: kBg,
        colorScheme: const ColorScheme.dark(primary: kPurple, secondary: kNeon),
      ),
      home: const Shell(),
    );
  }
}

class Shell extends StatefulWidget {
  const Shell({super.key});

  @override
  State<Shell> createState() => _ShellState();
}

class _ShellState extends State<Shell> {
  final music = MusicController(); // UMA instância pro app inteiro
  int _tab = 0;

  @override
  void dispose() {
    music.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: IndexedStack(
        index: _tab,
        children: [
          ExploreScreen(controller: music),
          LibraryScreen(controller: music),
          _GamesTab(music: music),
          // Coloque aqui as suas outras telas (Salas, COBRA CARDS...).
        ],
      ),
      bottomNavigationBar: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          MiniPlayer(
            controller: music,
            onTap: () => openPlayer(context, music),
          ),
          NavigationBar(
            selectedIndex: _tab,
            onDestinationSelected: (i) => setState(() => _tab = i),
            destinations: const [
              NavigationDestination(icon: Icon(Icons.explore), label: 'Explorar'),
              NavigationDestination(
                  icon: Icon(Icons.library_music), label: 'Biblioteca'),
              NavigationDestination(
                  icon: Icon(Icons.sports_esports), label: 'Jogos'),
            ],
          ),
        ],
      ),
    );
  }
}

class _GamesTab extends StatelessWidget {
  const _GamesTab({required this.music});

  final MusicController music;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Jogos')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          ListTile(
            leading: const Text('🧠', style: TextStyle(fontSize: 28)),
            title: const Text('Jogo da Memória'),
            onTap: () => Navigator.of(context).push(MaterialPageRoute<void>(
              builder: (_) => const MemoryGame(),
            )),
          ),
          ListTile(
            leading: const Text('🎧', style: TextStyle(fontSize: 28)),
            title: const Text('Adivinhe a Música'),
            onTap: () => Navigator.of(context).push(MaterialPageRoute<void>(
              builder: (_) => GuessSongGame(controller: music),
            )),
          ),
        ],
      ),
    );
  }
}
