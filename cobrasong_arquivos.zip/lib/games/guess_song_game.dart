// lib/games/guess_song_game.dart
// "Adivinhe a música": toca uma faixa do Audius e você escolhe o nome certo.
// Precisa de: audius_service.dart + music_controller.dart (em lib/services/)
// e just_audio + just_audio_background no pubspec.yaml
//
// Como abrir a partir da aba Jogos (use o mesmo MusicController do app):
//   Navigator.push(context, MaterialPageRoute(
//     builder: (_) => GuessSongGame(controller: music)));

import 'dart:async';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:just_audio/just_audio.dart';
import 'package:just_audio_background/just_audio_background.dart';
import '../services/audius_service.dart';
import '../services/music_controller.dart';

const _bg = Color(0xFF0B0B0F);
const _purple = Color(0xFF7C3AED);
const _neon = Color(0xFF39FF14);

class GuessSongGame extends StatefulWidget {
  // Usa o MESMO player do app (o just_audio_background só aceita um player).
  const GuessSongGame({super.key, required this.controller});

  final MusicController controller;

  @override
  State<GuessSongGame> createState() => _GuessSongGameState();
}

class _GuessSongGameState extends State<GuessSongGame> {
  static const _totalRounds = 5;
  static const _clipSeconds = 15;

  final _rng = Random();

  AudioPlayer get _player => widget.controller.player;

  List<Track> _pool = [];
  List<Track> _rounds = [];
  List<Track> _options = [];
  int _round = 0;
  int _score = 0;
  bool _loading = true;
  bool _answered = false;
  bool _audioFailed = false;
  String? _error;
  Track? _picked;
  Timer? _cut;

  @override
  void initState() {
    super.initState();
    widget.controller.autoAdvance = false;
    _player.pause();
    _load();
  }

  @override
  void dispose() {
    _cut?.cancel();
    _player.pause();
    widget.controller.autoAdvance = true;
    // Não damos dispose no player: ele é compartilhado com o app todo.
    super.dispose();
  }

  bool get _finished => !_loading && _error == null && _round >= _rounds.length;

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
      _round = 0;
      _score = 0;
    });
    try {
      final tracks = await widget.controller.catalog.trending();
      if (tracks.length < 4) throw Exception('Poucas músicas');
      tracks.shuffle(_rng);
      _pool = tracks;
      _rounds = tracks.take(min(_totalRounds, tracks.length)).toList();
      await _startRound();
    } catch (_) {
      _error = 'Não consegui carregar as músicas. '
          'Confira a internet e a chave da API do Audius.';
    }
    if (mounted) setState(() => _loading = false);
  }

  Future<void> _startRound() async {
    final correct = _rounds[_round];
    final others = _pool.where((t) => t.id != correct.id).toList()
      ..shuffle(_rng);
    _options = [correct, ...others.take(3)]..shuffle(_rng);
    _answered = false;
    _picked = null;
    _audioFailed = false;
    _cut?.cancel();
    try {
      await _player.setAudioSource(widget.controller.audioSourceFor(
        correct,
        // Título genérico, senão a notificação entregaria a resposta.
        tag: MediaItem(
          id: 'guess-${correct.id}',
          title: 'Adivinhe a música',
          artist: 'COBRASONG',
        ),
      ));
      _player.play();
      _cut = Timer(const Duration(seconds: _clipSeconds), () => _player.pause());
    } catch (_) {
      _audioFailed = true;
    }
    if (mounted) setState(() {});
  }

  Future<void> _replay() async {
    _cut?.cancel();
    try {
      await _player.seek(Duration.zero);
      _player.play();
      _cut = Timer(const Duration(seconds: _clipSeconds), () => _player.pause());
    } catch (_) {}
  }

  void _answer(Track t) {
    if (_answered) return;
    _cut?.cancel();
    _player.pause();
    setState(() {
      _answered = true;
      _picked = t;
      if (t.id == _rounds[_round].id) _score++;
    });
  }

  Future<void> _next() async {
    setState(() => _round++);
    if (_round < _rounds.length) {
      await _startRound();
    } else {
      await _player.stop();
    }
  }

  Color _optionColor(Track t) {
    if (!_answered) return const Color(0xFF1B1B26);
    if (t.id == _rounds[_round].id) return _neon.withOpacity(0.35);
    if (t.id == _picked?.id) return Colors.redAccent.withOpacity(0.35);
    return const Color(0xFF1B1B26);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _bg,
      appBar: AppBar(
        backgroundColor: _bg,
        foregroundColor: Colors.white,
        title: const Text('Adivinhe a Música'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: _body(),
      ),
    );
  }

  Widget _body() {
    if (_loading) {
      return const Center(child: CircularProgressIndicator(color: _neon));
    }
    if (_error != null) {
      return Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(_error!,
                textAlign: TextAlign.center,
                style: const TextStyle(color: Colors.white70)),
            const SizedBox(height: 12),
            FilledButton(
              style: FilledButton.styleFrom(backgroundColor: _purple),
              onPressed: _load,
              child: const Text('Tentar de novo'),
            ),
          ],
        ),
      );
    }
    if (_finished) {
      return Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text('🐍 Você acertou $_score de ${_rounds.length}!',
                style: const TextStyle(
                    color: _neon, fontSize: 24, fontWeight: FontWeight.bold)),
            const SizedBox(height: 16),
            FilledButton(
              style: FilledButton.styleFrom(backgroundColor: _purple),
              onPressed: _load,
              child: const Text('Jogar de novo'),
            ),
          ],
        ),
      );
    }

    final correct = _rounds[_round];
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Text('Rodada ${_round + 1} de ${_rounds.length}  •  Pontos: $_score',
            textAlign: TextAlign.center,
            style: const TextStyle(color: Colors.white70)),
        const SizedBox(height: 16),
        Center(
          child: IconButton(
            iconSize: 72,
            color: _neon,
            onPressed: _replay,
            icon: const Icon(Icons.replay_circle_filled),
          ),
        ),
        Text(
          _audioFailed
              ? 'Não deu pra tocar essa faixa. Responda ou pule.'
              : 'Qual é a música?',
          textAlign: TextAlign.center,
          style: const TextStyle(
              color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 16),
        for (final t in _options)
          Padding(
            padding: const EdgeInsets.only(bottom: 10),
            child: GestureDetector(
              onTap: () => _answer(t),
              child: Container(
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: _optionColor(t),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: _purple, width: 2),
                ),
                child: Text(t.title,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(color: Colors.white, fontSize: 16)),
              ),
            ),
          ),
        if (_answered) ...[
          const SizedBox(height: 4),
          // Crédito ao artista (a Audius pede que os artistas sejam creditados).
          Text('${correct.title} — ${correct.artist}',
              textAlign: TextAlign.center,
              style: const TextStyle(color: _neon)),
        ],
        const Spacer(),
        FilledButton(
          style: FilledButton.styleFrom(backgroundColor: _purple),
          onPressed: _next,
          child: Text(_answered ? 'Próxima' : 'Pular'),
        ),
      ],
    );
  }
}
