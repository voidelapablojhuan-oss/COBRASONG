// lib/games/memory_game.dart
// Jogo da memória (8 pares). Não precisa de nenhum pacote extra.
//
// Como abrir a partir da aba Jogos:
//   Navigator.push(context, MaterialPageRoute(builder: (_) => const MemoryGame()));

import 'dart:async';
import 'dart:math';
import 'package:flutter/material.dart';

const _bg = Color(0xFF0B0B0F);
const _purple = Color(0xFF7C3AED);
const _neon = Color(0xFF39FF14);

class MemoryGame extends StatefulWidget {
  const MemoryGame({super.key});

  @override
  State<MemoryGame> createState() => _MemoryGameState();
}

class _MemoryGameState extends State<MemoryGame> {
  static const _symbols = ['🐍', '🎵', '🎧', '🎸', '🥁', '🎹', '🎤', '🎺'];

  late List<String> _cards;
  late List<bool> _revealed;
  late List<bool> _matched;
  int? _first;
  bool _busy = false;
  int _moves = 0;

  @override
  void initState() {
    super.initState();
    _newGame();
  }

  void _newGame() {
    _cards = [..._symbols, ..._symbols]..shuffle(Random());
    _revealed = List.filled(_cards.length, false);
    _matched = List.filled(_cards.length, false);
    _first = null;
    _busy = false;
    _moves = 0;
  }

  bool get _won => _matched.every((m) => m);

  Future<void> _tap(int i) async {
    if (_busy || _revealed[i] || _matched[i]) return;

    setState(() => _revealed[i] = true);

    if (_first == null) {
      _first = i;
      return;
    }

    final a = _first!;
    _first = null;

    if (_cards[a] == _cards[i]) {
      setState(() {
        _matched[a] = true;
        _matched[i] = true;
        _moves++;
      });
    } else {
      _busy = true;
      await Future.delayed(const Duration(milliseconds: 800));
      if (!mounted) return;
      setState(() {
        _revealed[a] = false;
        _revealed[i] = false;
        _busy = false;
        _moves++;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _bg,
      appBar: AppBar(
        backgroundColor: _bg,
        foregroundColor: Colors.white,
        title: const Text('Jogo da Memória'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            Text(
              _won ? '🐍 Você venceu em $_moves jogadas!' : 'Jogadas: $_moves',
              style: const TextStyle(
                color: _neon,
                fontSize: 20,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 16),
            Expanded(
              child: GridView.builder(
                itemCount: _cards.length,
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 4,
                  mainAxisSpacing: 10,
                  crossAxisSpacing: 10,
                ),
                itemBuilder: (context, i) {
                  final show = _revealed[i] || _matched[i];
                  return GestureDetector(
                    onTap: () => _tap(i),
                    child: AnimatedContainer(
                      duration: const Duration(milliseconds: 200),
                      decoration: BoxDecoration(
                        color: _matched[i]
                            ? _neon.withOpacity(0.25)
                            : (show ? const Color(0xFF1B1B26) : _purple),
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(
                          color: _matched[i] ? _neon : _purple,
                          width: 2,
                        ),
                      ),
                      alignment: Alignment.center,
                      child: Text(
                        show ? _cards[i] : '?',
                        style: const TextStyle(fontSize: 32),
                      ),
                    ),
                  );
                },
              ),
            ),
            const SizedBox(height: 12),
            FilledButton(
              style: FilledButton.styleFrom(backgroundColor: _purple),
              onPressed: () => setState(_newGame),
              child: const Text('Novo jogo'),
            ),
          ],
        ),
      ),
    );
  }
}
