// lib/screens/explore_screen.dart
// Explorar: músicas em alta (Audius + Jamendo), com atalho pra busca.
// Use como uma aba do app (o MiniPlayer fica no seu menu de baixo).

import 'package:flutter/material.dart';
import '../services/audius_service.dart';
import '../services/music_controller.dart';
import '../widgets/ui_common.dart';
import 'search_screen.dart';

class ExploreScreen extends StatefulWidget {
  const ExploreScreen({super.key, required this.controller});

  final MusicController controller;

  @override
  State<ExploreScreen> createState() => _ExploreScreenState();
}

class _ExploreScreenState extends State<ExploreScreen> {
  List<Track> _tracks = [];
  bool _loading = true;
  String? _error;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final r = await widget.controller.catalog.trending();
      if (!mounted) return;
      setState(() {
        _tracks = r;
        _loading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _error = 'Não consegui carregar as músicas ($e). '
            'Confira a internet e as chaves das APIs.';
        _loading = false;
      });
    }
  }

  Widget _body() {
    if (_loading) {
      return const Center(child: CircularProgressIndicator(color: kNeon));
    }
    if (_error != null) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(_error!,
                  textAlign: TextAlign.center,
                  style: const TextStyle(color: Colors.redAccent)),
              const SizedBox(height: 12),
              FilledButton(
                style: FilledButton.styleFrom(backgroundColor: kPurple),
                onPressed: _load,
                child: const Text('Tentar de novo'),
              ),
            ],
          ),
        ),
      );
    }
    return RefreshIndicator(
      color: kNeon,
      onRefresh: _load,
      child: ListView.builder(
        itemCount: _tracks.length + 2,
        itemBuilder: (context, i) {
          if (i == 0) {
            return const Padding(
              padding: EdgeInsets.fromLTRB(16, 8, 16, 0),
              child: Text('Em alta agora',
                  style: TextStyle(
                      color: Colors.white,
                      fontSize: 20,
                      fontWeight: FontWeight.bold)),
            );
          }
          if (i == 1) {
            return PlayButtons(controller: widget.controller, tracks: _tracks);
          }
          final index = i - 2;
          return TrackTile(
            controller: widget.controller,
            track: _tracks[index],
            onTap: () => widget.controller.playQueue(_tracks, index),
          );
        },
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: kBg,
      appBar: AppBar(
        backgroundColor: kBg,
        foregroundColor: Colors.white,
        title: const Text('Explorar'),
        actions: [
          IconButton(
            tooltip: 'Buscar',
            icon: const Icon(Icons.search),
            onPressed: () => Navigator.of(context).push(MaterialPageRoute<void>(
              builder: (_) => SearchScreen(controller: widget.controller),
            )),
          ),
        ],
      ),
      body: _body(),
    );
  }
}
