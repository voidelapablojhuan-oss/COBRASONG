// lib/screens/library_screen.dart
// Biblioteca: Favoritas, Playlists e Recentes.
// Use como uma aba do app (o MiniPlayer fica no seu menu de baixo).

import 'package:flutter/material.dart';
import '../services/audius_service.dart';
import '../services/music_controller.dart';
import '../widgets/ui_common.dart';
import 'player_screen.dart';

const _white = TextStyle(color: Colors.white);
const _white60 = TextStyle(color: Colors.white60);

class LibraryScreen extends StatelessWidget {
  const LibraryScreen({super.key, required this.controller});

  final MusicController controller;

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 3,
      child: Scaffold(
        backgroundColor: kBg,
        appBar: AppBar(
          backgroundColor: kBg,
          foregroundColor: Colors.white,
          title: const Text('Biblioteca'),
          bottom: const TabBar(
            indicatorColor: kNeon,
            labelColor: kNeon,
            unselectedLabelColor: Colors.white60,
            tabs: [
              Tab(text: 'Favoritas'),
              Tab(text: 'Playlists'),
              Tab(text: 'Recentes'),
            ],
          ),
        ),
        body: ListenableBuilder(
          listenable: controller.library,
          builder: (context, _) => TabBarView(
            children: [
              _TrackList(
                controller: controller,
                tracks: controller.library.favorites,
                emptyText:
                    'Toque no coração de uma música pra ela aparecer aqui.',
              ),
              _Playlists(controller: controller),
              _TrackList(
                controller: controller,
                tracks: controller.library.history,
                emptyText: 'Nenhuma música tocada ainda.',
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _TrackList extends StatelessWidget {
  const _TrackList({
    required this.controller,
    required this.tracks,
    required this.emptyText,
  });

  final MusicController controller;
  final List<Track> tracks;
  final String emptyText;

  @override
  Widget build(BuildContext context) {
    if (tracks.isEmpty) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Text(emptyText,
              textAlign: TextAlign.center,
              style: const TextStyle(color: Colors.white54)),
        ),
      );
    }
    return ListView.builder(
      itemCount: tracks.length + 1,
      itemBuilder: (context, i) {
        if (i == 0) {
          return PlayButtons(controller: controller, tracks: tracks);
        }
        return TrackTile(
          controller: controller,
          track: tracks[i - 1],
          onTap: () => controller.playQueue(tracks, i - 1),
        );
      },
    );
  }
}

class _Playlists extends StatelessWidget {
  const _Playlists({required this.controller});

  final MusicController controller;

  @override
  Widget build(BuildContext context) {
    final lists = controller.library.playlists;
    return ListView(
      children: [
        ListTile(
          leading: const Icon(Icons.add, color: kNeon),
          title: const Text('Nova playlist', style: _white),
          onTap: () async {
            final name = await promptText(context, 'Nome da playlist');
            if (name != null) controller.library.createPlaylist(name);
          },
        ),
        for (var i = 0; i < lists.length; i++)
          ListTile(
            leading: const Icon(Icons.queue_music, color: Colors.white70),
            title: Text(lists[i].name, style: _white),
            subtitle:
                Text('${lists[i].tracks.length} músicas', style: _white60),
            trailing: IconButton(
              tooltip: 'Apagar playlist',
              icon: const Icon(Icons.delete_outline, color: Colors.white54),
              onPressed: () => controller.library.deletePlaylist(i),
            ),
            onTap: () => Navigator.of(context).push(MaterialPageRoute<void>(
              builder: (_) => PlaylistScreen(controller: controller, index: i),
            )),
          ),
      ],
    );
  }
}

/// Dentro de uma playlist. Deslize uma música pro lado pra tirar da playlist.
class PlaylistScreen extends StatelessWidget {
  const PlaylistScreen({
    super.key,
    required this.controller,
    required this.index,
  });

  final MusicController controller;
  final int index;

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: controller.library,
      builder: (context, _) {
        final lists = controller.library.playlists;
        final pl = index < lists.length ? lists[index] : null;
        return Scaffold(
          backgroundColor: kBg,
          appBar: AppBar(
            backgroundColor: kBg,
            foregroundColor: Colors.white,
            title: Text(pl?.name ?? 'Playlist'),
          ),
          body: (pl == null || pl.tracks.isEmpty)
              ? const Center(
                  child: Padding(
                    padding: EdgeInsets.all(24),
                    child: Text(
                      'Playlist vazia. Use o menu ⋮ de uma música pra adicionar aqui.',
                      textAlign: TextAlign.center,
                      style: TextStyle(color: Colors.white54),
                    ),
                  ),
                )
              : ListView.builder(
                  itemCount: pl.tracks.length + 1,
                  itemBuilder: (context, i) {
                    if (i == 0) {
                      return PlayButtons(
                          controller: controller, tracks: pl.tracks);
                    }
                    final t = pl.tracks[i - 1];
                    return Dismissible(
                      key: ValueKey('${pl.name}_${t.id}'),
                      direction: DismissDirection.endToStart,
                      background: Container(
                        color: Colors.redAccent,
                        alignment: Alignment.centerRight,
                        padding: const EdgeInsets.only(right: 20),
                        child: const Icon(Icons.delete, color: Colors.white),
                      ),
                      onDismissed: (_) =>
                          controller.library.removeFromPlaylist(index, t.id),
                      child: TrackTile(
                        controller: controller,
                        track: t,
                        onTap: () => controller.playQueue(pl.tracks, i - 1),
                      ),
                    );
                  },
                ),
          bottomNavigationBar: MiniPlayer(
            controller: controller,
            onTap: () => openPlayer(context, controller),
          ),
        );
      },
    );
  }
}
