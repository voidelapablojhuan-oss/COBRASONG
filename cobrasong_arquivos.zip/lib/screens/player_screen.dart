// lib/screens/player_screen.dart
// Player em tela cheia. Abra com:  openPlayer(context, music);

import 'package:flutter/material.dart';
import '../services/music_controller.dart';
import '../widgets/ui_common.dart';

void openPlayer(BuildContext context, MusicController c) {
  Navigator.of(context).push(MaterialPageRoute<void>(
    fullscreenDialog: true,
    builder: (_) => PlayerScreen(controller: c),
  ));
}

String _fmt(Duration d) {
  final s = d.inSeconds.remainder(60).toString().padLeft(2, '0');
  return '${d.inMinutes}:$s';
}

class PlayerScreen extends StatelessWidget {
  const PlayerScreen({super.key, required this.controller});

  final MusicController controller;

  void _sleepSheet(BuildContext context) {
    showModalBottomSheet<void>(
      context: context,
      backgroundColor: kCard,
      builder: (ctx) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const ListTile(
              title: Text('Parar a música em…',
                  style: TextStyle(
                      color: Colors.white, fontWeight: FontWeight.bold)),
            ),
            for (final m in const [15, 30, 45, 60])
              ListTile(
                title: Text('$m minutos',
                    style: const TextStyle(color: Colors.white)),
                onTap: () {
                  controller.setSleepTimer(Duration(minutes: m));
                  Navigator.pop(ctx);
                },
              ),
            if (controller.sleepEndsAt != null)
              ListTile(
                title: const Text('Cancelar timer',
                    style: TextStyle(color: Colors.redAccent)),
                onTap: () {
                  controller.setSleepTimer(null);
                  Navigator.pop(ctx);
                },
              ),
          ],
        ),
      ),
    );
  }

  void _queueSheet(BuildContext context) {
    showModalBottomSheet<void>(
      context: context,
      backgroundColor: kCard,
      isScrollControlled: true,
      builder: (ctx) => ListenableBuilder(
        listenable: controller,
        builder: (ctx, _) {
          final up = controller.upcoming;
          final shown = up.length > 100 ? up.sublist(0, 100) : up;
          return SizedBox(
            height: MediaQuery.of(ctx).size.height * 0.6,
            child: Column(
              children: [
                const ListTile(
                  title: Text('A seguir',
                      style: TextStyle(
                          color: Colors.white, fontWeight: FontWeight.bold)),
                ),
                Expanded(
                  child: shown.isEmpty
                      ? const Center(
                          child: Padding(
                            padding: EdgeInsets.all(24),
                            child: Text(
                              'Fila vazia. Com a reprodução automática ligada, '
                              'novas músicas entram sozinhas.',
                              textAlign: TextAlign.center,
                              style: TextStyle(color: Colors.white54),
                            ),
                          ),
                        )
                      : ListView.builder(
                          itemCount: shown.length,
                          itemBuilder: (_, i) => ListTile(
                            leading: TrackCover(track: shown[i], size: 40),
                            title: Text(shown[i].title,
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                                style: const TextStyle(color: Colors.white)),
                            subtitle: Text(shown[i].artist,
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                                style: const TextStyle(color: Colors.white60)),
                            onTap: () {
                              controller.jumpToUpcoming(i);
                              Navigator.pop(ctx);
                            },
                          ),
                        ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: Listenable.merge([controller, controller.library]),
      builder: (context, _) {
        final t = controller.current;
        final width = MediaQuery.of(context).size.width;
        final coverSize = (width - 64).clamp(200.0, 360.0).toDouble();
        final sleeping = controller.sleepEndsAt != null;

        return Scaffold(
          backgroundColor: kBg,
          appBar: AppBar(
            backgroundColor: kBg,
            foregroundColor: Colors.white,
            centerTitle: true,
            title: const Text('Tocando agora'),
            leading: IconButton(
              icon: const Icon(Icons.keyboard_arrow_down, size: 32),
              onPressed: () => Navigator.pop(context),
            ),
            actions: [
              IconButton(
                tooltip: 'Timer para dormir',
                icon: Icon(sleeping ? Icons.bedtime : Icons.bedtime_outlined,
                    color: sleeping ? kNeon : Colors.white),
                onPressed: () => _sleepSheet(context),
              ),
              IconButton(
                tooltip: 'Fila',
                icon: const Icon(Icons.queue_music),
                onPressed: () => _queueSheet(context),
              ),
            ],
          ),
          body: t == null
              ? const Center(
                  child: Text('Nada tocando agora',
                      style: TextStyle(color: Colors.white54)))
              : SingleChildScrollView(
                  padding: const EdgeInsets.symmetric(horizontal: 24),
                  child: Column(
                    children: [
                      const SizedBox(height: 8),
                      TrackCover(track: t, size: coverSize, radius: 16),
                      const SizedBox(height: 24),
                      Row(
                        children: [
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(t.title,
                                    maxLines: 2,
                                    overflow: TextOverflow.ellipsis,
                                    style: const TextStyle(
                                        color: Colors.white,
                                        fontSize: 22,
                                        fontWeight: FontWeight.bold)),
                                const SizedBox(height: 4),
                                Text(t.artist,
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                    style: const TextStyle(
                                        color: Colors.white60, fontSize: 16)),
                              ],
                            ),
                          ),
                          IconButton(
                            iconSize: 30,
                            onPressed: () =>
                                controller.library.toggleFavorite(t),
                            icon: Icon(
                              controller.library.isFavorite(t.id)
                                  ? Icons.favorite
                                  : Icons.favorite_border,
                              color: controller.library.isFavorite(t.id)
                                  ? kNeon
                                  : Colors.white70,
                            ),
                          ),
                        ],
                      ),
                      if (controller.error != null) ...[
                        const SizedBox(height: 8),
                        Text(controller.error!,
                            style: const TextStyle(color: Colors.redAccent)),
                      ],
                      const SizedBox(height: 8),
                      _SeekBar(controller: controller),
                      const SizedBox(height: 8),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: [
                          IconButton(
                            tooltip: 'Aleatório',
                            iconSize: 28,
                            color: controller.shuffle ? kNeon : Colors.white70,
                            onPressed: controller.toggleShuffle,
                            icon: const Icon(Icons.shuffle),
                          ),
                          IconButton(
                            iconSize: 40,
                            color: Colors.white,
                            onPressed: controller.previous,
                            icon: const Icon(Icons.skip_previous),
                          ),
                          controller.loading
                              ? const SizedBox(
                                  width: 72,
                                  height: 72,
                                  child: Padding(
                                    padding: EdgeInsets.all(20),
                                    child: CircularProgressIndicator(
                                        strokeWidth: 3, color: kNeon),
                                  ),
                                )
                              : IconButton(
                                  iconSize: 72,
                                  color: kNeon,
                                  onPressed: controller.togglePlay,
                                  icon: Icon(controller.isPlaying
                                      ? Icons.pause_circle_filled
                                      : Icons.play_circle_filled),
                                ),
                          IconButton(
                            iconSize: 40,
                            color: Colors.white,
                            onPressed: controller.next,
                            icon: const Icon(Icons.skip_next),
                          ),
                          IconButton(
                            tooltip: 'Repetir',
                            iconSize: 28,
                            color: controller.repeat == RepeatMode.off
                                ? Colors.white70
                                : kNeon,
                            onPressed: controller.cycleRepeat,
                            icon: Icon(controller.repeat == RepeatMode.one
                                ? Icons.repeat_one
                                : Icons.repeat),
                          ),
                        ],
                      ),
                      const SizedBox(height: 8),
                      SwitchListTile(
                        contentPadding: EdgeInsets.zero,
                        activeColor: kNeon,
                        title: const Text('Reprodução automática',
                            style: TextStyle(color: Colors.white)),
                        subtitle: const Text(
                            'Quando a fila acabar, continua com músicas parecidas',
                            style: TextStyle(color: Colors.white54)),
                        value: controller.autoplay,
                        onChanged: (_) => controller.toggleAutoplay(),
                      ),
                      if (sleeping)
                        Padding(
                          padding: const EdgeInsets.only(top: 4),
                          child: Text(
                            'A música para às '
                            '${TimeOfDay.fromDateTime(controller.sleepEndsAt!).format(context)}',
                            style: const TextStyle(color: kNeon),
                          ),
                        ),
                      const SizedBox(height: 24),
                    ],
                  ),
                ),
        );
      },
    );
  }
}

/// Barra de progresso que dá pra arrastar.
class _SeekBar extends StatefulWidget {
  const _SeekBar({required this.controller});

  final MusicController controller;

  @override
  State<_SeekBar> createState() => _SeekBarState();
}

class _SeekBarState extends State<_SeekBar> {
  double? _drag;

  @override
  Widget build(BuildContext context) {
    final c = widget.controller;
    return StreamBuilder<Duration>(
      stream: c.positionStream,
      builder: (context, snap) {
        final pos = snap.data ?? Duration.zero;
        final total =
            c.duration ?? Duration(seconds: c.current?.durationSec ?? 0);
        final maxMs = total.inMilliseconds.toDouble();
        final hasLength = maxMs > 0;
        final value = (_drag ?? pos.inMilliseconds.toDouble())
            .clamp(0.0, hasLength ? maxMs : 1.0)
            .toDouble();

        return Column(
          children: [
            Slider(
              value: value,
              max: hasLength ? maxMs : 1.0,
              activeColor: kNeon,
              inactiveColor: Colors.white24,
              onChanged: hasLength ? (v) => setState(() => _drag = v) : null,
              onChangeEnd: (v) {
                c.seek(Duration(milliseconds: v.round()));
                setState(() => _drag = null);
              },
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(_fmt(Duration(milliseconds: value.round())),
                      style: const TextStyle(color: Colors.white60)),
                  Text(hasLength ? _fmt(total) : '--:--',
                      style: const TextStyle(color: Colors.white60)),
                ],
              ),
            ),
          ],
        );
      },
    );
  }
}
