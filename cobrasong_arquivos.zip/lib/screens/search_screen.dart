// lib/screens/search_screen.dart
// Busca nas duas fontes (Audius + Jamendo).
//
// Como abrir (passe o MESMO MusicController usado no resto do app):
//   Navigator.push(context, MaterialPageRoute(
//     builder: (_) => SearchScreen(controller: music)));

import 'dart:async';
import 'package:flutter/material.dart';
import '../services/audius_service.dart';
import '../services/music_controller.dart';
import '../widgets/ui_common.dart';
import 'player_screen.dart';

class SearchScreen extends StatefulWidget {
  const SearchScreen({super.key, required this.controller});

  final MusicController controller;

  @override
  State<SearchScreen> createState() => _SearchScreenState();
}

class _SearchScreenState extends State<SearchScreen> {
  final _text = TextEditingController();
  Timer? _debounce;

  List<Track> _results = [];
  bool _loading = false;
  String? _error;
  String _lastQuery = '';

  @override
  void dispose() {
    _debounce?.cancel();
    _text.dispose();
    super.dispose();
  }

  void _onChanged(String q) {
    _debounce?.cancel();
    _debounce = Timer(const Duration(milliseconds: 450), () => _search(q));
  }

  Future<void> _search(String raw) async {
    final q = raw.trim();
    if (q.isEmpty) {
      setState(() {
        _results = [];
        _error = null;
        _loading = false;
        _lastQuery = '';
      });
      return;
    }
    setState(() {
      _loading = true;
      _error = null;
      _lastQuery = q;
    });
    try {
      final r = await widget.controller.catalog.search(q);
      if (!mounted || q != _lastQuery) return; // ignora resposta antiga
      setState(() {
        _results = r;
        _loading = false;
      });
    } catch (e) {
      if (!mounted) return;
      // Mostra o motivo real (ex.: "Audius respondeu 401") pra facilitar achar o problema.
      setState(() {
        _error = 'Erro na busca: $e';
        _loading = false;
      });
    }
  }

  Widget _body() {
    if (_loading) {
      return const Center(child: CircularProgressIndicator(color: kNeon));
    }
    if (_error != null) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Text(_error!,
              textAlign: TextAlign.center,
              style: const TextStyle(color: Colors.redAccent)),
        ),
      );
    }
    if (_lastQuery.isEmpty) {
      return const Center(
        child: Text('Digite o nome de uma música ou artista',
            style: TextStyle(color: Colors.white54)),
      );
    }
    if (_results.isEmpty) {
      return const Center(
        child: Text('Nenhum resultado', style: TextStyle(color: Colors.white54)),
      );
    }
    return ListView.builder(
      itemCount: _results.length,
      itemBuilder: (context, i) => TrackTile(
        controller: widget.controller,
        track: _results[i],
        onTap: () => widget.controller.playQueue(_results, i),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: kBg,
      appBar: AppBar(
        backgroundColor: kBg,
        foregroundColor: Colors.white,
        title: TextField(
          controller: _text,
          autofocus: true,
          onChanged: _onChanged,
          onSubmitted: _search,
          textInputAction: TextInputAction.search,
          style: const TextStyle(color: Colors.white),
          cursorColor: kNeon,
          decoration: const InputDecoration(
            hintText: 'Buscar músicas…',
            hintStyle: TextStyle(color: Colors.white38),
            border: InputBorder.none,
          ),
        ),
      ),
      body: _body(),
      bottomNavigationBar: MiniPlayer(
        controller: widget.controller,
        onTap: () => openPlayer(context, widget.controller),
      ),
    );
  }
}
