// lib/services/audius_service.dart
// Dependência no pubspec.yaml:  http: ^1.2.0   e   just_audio: ^0.9.40
//
// A chave da API NÃO vai no código (o repositório é público).
// Passe na hora de rodar/compilar:
//   flutter run --dart-define=AUDIUS_API_KEY=sua_chave
// No GitHub Actions, guarde a chave em Settings > Secrets e use o mesmo --dart-define.

import 'dart:convert';
import 'package:http/http.dart' as http;

class Track {
  final String id;
  final String title;
  final String artist;
  final String? artworkUrl;
  final int durationSec;
  final bool streamable;

  /// De onde vem a faixa: 'audius' ou 'jamendo'.
  final String source;

  /// Link direto do áudio (o Jamendo já entrega). No Audius fica nulo e o link é montado.
  final String? directUrl;

  const Track({
    required this.id,
    required this.title,
    required this.artist,
    this.artworkUrl,
    this.durationSec = 0,
    this.streamable = true,
    this.source = 'audius',
    this.directUrl,
  });

  factory Track.fromJson(Map<String, dynamic> j) {
    final art = j['artwork'] as Map<String, dynamic>?;
    final user = j['user'] as Map<String, dynamic>?;
    return Track(
      id: j['id'] as String,
      title: (j['title'] as String?) ?? 'Sem título',
      artist: (user?['name'] as String?) ?? 'Artista desconhecido',
      artworkUrl: (art?['480x480'] ?? art?['150x150']) as String?,
      durationSec: (j['duration'] as num?)?.toInt() ?? 0,
      streamable: (j['is_streamable'] as bool?) ?? true,
    );
  }

  /// Usado para salvar a faixa no celular (favoritos, playlists, recentes).
  Map<String, dynamic> toMap() => {
        'id': id,
        'title': title,
        'artist': artist,
        'artworkUrl': artworkUrl,
        'durationSec': durationSec,
        'source': source,
        'directUrl': directUrl,
      };

  factory Track.fromMap(Map<String, dynamic> m) => Track(
        id: m['id'] as String,
        title: (m['title'] as String?) ?? 'Sem título',
        artist: (m['artist'] as String?) ?? 'Artista desconhecido',
        artworkUrl: m['artworkUrl'] as String?,
        durationSec: (m['durationSec'] as num?)?.toInt() ?? 0,
        source: (m['source'] as String?) ?? 'audius',
        directUrl: m['directUrl'] as String?,
      );
}

class AudiusService {
  static const _base = 'https://api.audius.co/v1';
  static const _appName = 'COBRASONG';
  static const _apiKey = String.fromEnvironment('AUDIUS_API_KEY');

  /// Use também no just_audio (AudioSource.uri(..., headers: api.headers)).
  Map<String, String> get headers =>
      _apiKey.isEmpty ? const {} : {'Authorization': 'Bearer $_apiKey'};

  Future<List<Track>> _fetchTracks(String path, Map<String, String> params) async {
    final uri = Uri.parse('$_base$path')
        .replace(queryParameters: {...params, 'app_name': _appName});
    final res = await http.get(uri, headers: headers);
    if (res.statusCode != 200) {
      // Ex.: 401/403 = chave da API ausente ou inválida.
      throw Exception('Audius respondeu ${res.statusCode}');
    }
    final data = jsonDecode(res.body)['data'] as List<dynamic>;
    return data
        .map((e) => Track.fromJson(e as Map<String, dynamic>))
        .where((t) => t.streamable) // esconde faixas indisponíveis
        .toList();
  }

  /// Músicas em alta. time: 'week', 'month' ou 'allTime'.
  Future<List<Track>> trending({String time = 'week', String? genre}) =>
      _fetchTracks('/tracks/trending', {
        'time': time,
        if (genre != null) 'genre': genre,
      });

  Future<List<Track>> search(String query) =>
      _fetchTracks('/tracks/search', {'query': query});

  String streamUrl(String trackId) =>
      '$_base/tracks/$trackId/stream?app_name=$_appName';
}

// ---------------------------------------------------------------
// Exemplo de uso no player (just_audio):
//
//   final api = AudiusService();
//   final player = AudioPlayer();
//   List<Track> queue = await api.trending();
//   int index = 0;
//
//   Future<void> playAt(int i) async {
//     index = i;
//     await player.setAudioSource(AudioSource.uri(
//       Uri.parse(api.streamUrl(queue[i].id)),
//       headers: api.headers,
//     ));
//     player.play();
//   }
//
//   // próxima faixa: playAt((index + 1) % queue.length);
//   // Mostre sempre o nome do artista na tela (a Audius pede crédito aos artistas).
//
// Android: confirme a permissão <uses-permission android:name="android.permission.INTERNET"/>
// em android/app/src/main/AndroidManifest.xml.
// ---------------------------------------------------------------
