// lib/services/catalog.dart
// Junta várias fontes de música em uma lista só (intercalando os resultados).
// Se uma fonte falhar (ex.: sem chave), as outras continuam funcionando.

import 'audius_service.dart';
import 'jamendo_service.dart';

class MusicCatalog {
  MusicCatalog({AudiusService? audius, JamendoService? jamendo})
      : audius = audius ?? AudiusService(),
        jamendo = jamendo ?? JamendoService();

  final AudiusService audius;
  final JamendoService jamendo;

  Future<List<Track>> trending() =>
      _merge([audius.trending(), jamendo.trending()]);

  Future<List<Track>> search(String query) =>
      _merge([audius.search(query), jamendo.search(query)]);

  Future<List<Track>> _merge(List<Future<List<Track>>> sources) async {
    Object? firstError;

    final lists = await Future.wait(sources.map((f) async {
      try {
        return await f;
      } catch (e) {
        firstError ??= e;
        return <Track>[];
      }
    }));

    // Intercala: 1ª do Audius, 1ª do Jamendo, 2ª do Audius, ...
    final merged = <Track>[];
    var longest = 0;
    for (final l in lists) {
      if (l.length > longest) longest = l.length;
    }
    for (var i = 0; i < longest; i++) {
      for (final l in lists) {
        if (i < l.length) merged.add(l[i]);
      }
    }

    if (merged.isEmpty && firstError != null) {
      throw firstError!;
    }
    return merged;
  }
}
