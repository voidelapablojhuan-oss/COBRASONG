// lib/services/jamendo_service.dart
// Músicas do Jamendo (catálogo de música independente, licença Creative Commons).
//
// 1) Crie uma conta e um app em https://devportal.jamendo.com e copie o Client ID.
// 2) Passe na hora de rodar/compilar (não cole no código, o repositório é público):
//      flutter run --dart-define=JAMENDO_CLIENT_ID=seu_client_id
//    No GitHub Actions, guarde em Settings > Secrets e use o mesmo --dart-define.
//
// Uso pessoal/entre amigos (sem fins comerciais) é permitido. Se um dia o app for
// comercial, o Jamendo exige licença comercial. Sempre mostre o nome do artista.

import 'dart:convert';
import 'package:http/http.dart' as http;
import 'audius_service.dart' show Track;

class JamendoService {
  static const _base = 'https://api.jamendo.com/v3.0';
  static const _clientId = String.fromEnvironment('JAMENDO_CLIENT_ID');

  bool get configured => _clientId.isNotEmpty;

  Future<List<Track>> _fetch(Map<String, String> params) async {
    if (!configured) {
      throw Exception('Falta o JAMENDO_CLIENT_ID');
    }
    final uri = Uri.parse('$_base/tracks/').replace(queryParameters: {
      'client_id': _clientId,
      'format': 'json',
      'limit': '50',
      'audioformat': 'mp32',
      ...params,
    });
    final res = await http.get(uri);
    if (res.statusCode != 200) {
      throw Exception('Jamendo respondeu ${res.statusCode}');
    }
    final body = jsonDecode(res.body) as Map<String, dynamic>;

    // O Jamendo pode responder 200 e avisar o erro dentro de "headers".
    final h = body['headers'] as Map<String, dynamic>?;
    if (h != null && h['status'] == 'failed') {
      throw Exception('Jamendo: ${h['error_message']}');
    }

    final results = (body['results'] as List<dynamic>?) ?? const [];
    return results
        .map((e) => _fromJson(e as Map<String, dynamic>))
        .where((t) => t.directUrl != null && t.directUrl!.isNotEmpty)
        .toList();
  }

  Track _fromJson(Map<String, dynamic> j) => Track(
        id: 'jm_${j['id']}',
        title: (j['name'] as String?) ?? 'Sem título',
        artist: (j['artist_name'] as String?) ?? 'Artista desconhecido',
        artworkUrl: (j['image'] as String?) ?? (j['album_image'] as String?),
        durationSec: int.tryParse('${j['duration']}') ?? 0,
        source: 'jamendo',
        directUrl: j['audio'] as String?,
      );

  /// Mais ouvidas da semana.
  Future<List<Track>> trending() => _fetch({'order': 'popularity_week'});

  Future<List<Track>> search(String query) => _fetch({'search': query});
}
