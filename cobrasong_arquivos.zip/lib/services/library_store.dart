// lib/services/library_store.dart
// Favoritos, playlists e músicas recentes, salvos no próprio celular.
// Dependência no pubspec.yaml:  shared_preferences: ^2.2.0

import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'audius_service.dart';

class Playlist {
  Playlist(this.name, [List<Track>? tracks]) : tracks = tracks ?? [];

  String name;
  final List<Track> tracks;

  Map<String, dynamic> toMap() => {
        'name': name,
        'tracks': tracks.map((t) => t.toMap()).toList(),
      };

  factory Playlist.fromMap(Map<String, dynamic> m) => Playlist(
        (m['name'] as String?) ?? 'Playlist',
        ((m['tracks'] as List<dynamic>?) ?? const [])
            .map((e) => Track.fromMap(e as Map<String, dynamic>))
            .toList(),
      );
}

class LibraryStore extends ChangeNotifier {
  static const _key = 'cobrasong_library_v1';
  static const _maxHistory = 50;

  final List<Track> favorites = [];
  final List<Track> history = [];
  final List<Playlist> playlists = [];

  List<Track> _tracksFrom(dynamic raw) => ((raw as List<dynamic>?) ?? const [])
      .map((e) => Track.fromMap(e as Map<String, dynamic>))
      .toList();

  Future<void> load() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final raw = prefs.getString(_key);
      if (raw == null) return;
      final m = jsonDecode(raw) as Map<String, dynamic>;
      favorites
        ..clear()
        ..addAll(_tracksFrom(m['favorites']));
      history
        ..clear()
        ..addAll(_tracksFrom(m['history']));
      playlists
        ..clear()
        ..addAll(((m['playlists'] as List<dynamic>?) ?? const [])
            .map((e) => Playlist.fromMap(e as Map<String, dynamic>)));
      notifyListeners();
    } catch (_) {
      // Se o arquivo salvo estiver corrompido, começa do zero.
    }
  }

  Future<void> _save() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString(
        _key,
        jsonEncode({
          'favorites': favorites.map((t) => t.toMap()).toList(),
          'history': history.map((t) => t.toMap()).toList(),
          'playlists': playlists.map((p) => p.toMap()).toList(),
        }),
      );
    } catch (_) {}
  }

  void _changed() {
    notifyListeners();
    _save();
  }

  // ---------- Favoritos ----------

  bool isFavorite(String id) => favorites.any((t) => t.id == id);

  void toggleFavorite(Track t) {
    final i = favorites.indexWhere((f) => f.id == t.id);
    if (i >= 0) {
      favorites.removeAt(i);
    } else {
      favorites.insert(0, t);
    }
    _changed();
  }

  // ---------- Recentes ----------

  void addToHistory(Track t) {
    history.removeWhere((h) => h.id == t.id);
    history.insert(0, t);
    if (history.length > _maxHistory) {
      history.removeRange(_maxHistory, history.length);
    }
    _changed();
  }

  void clearHistory() {
    history.clear();
    _changed();
  }

  // ---------- Playlists ----------

  /// Cria a playlist e devolve a posição dela na lista.
  int createPlaylist(String name) {
    playlists.add(Playlist(name));
    _changed();
    return playlists.length - 1;
  }

  void deletePlaylist(int index) {
    if (index < 0 || index >= playlists.length) return;
    playlists.removeAt(index);
    _changed();
  }

  void addToPlaylist(int index, Track t) {
    if (index < 0 || index >= playlists.length) return;
    final p = playlists[index];
    if (p.tracks.any((x) => x.id == t.id)) return; // sem duplicar
    p.tracks.add(t);
    _changed();
  }

  void removeFromPlaylist(int index, String trackId) {
    if (index < 0 || index >= playlists.length) return;
    playlists[index].tracks.removeWhere((t) => t.id == trackId);
    _changed();
  }
}
