// lib/services/music_controller.dart
// O "cérebro" do player. Crie UMA instância só no app inteiro:
//   final music = MusicController();
//
// Recursos: fila, reprodução automática, aleatório, repetir (tudo/uma),
// próxima/anterior, tocar a seguir, adicionar à fila, timer para dormir,
// pular faixa indisponível e registrar recentes.

import 'dart:async';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:just_audio/just_audio.dart';
import 'package:just_audio_background/just_audio_background.dart';
import 'audius_service.dart';
import 'catalog.dart';
import 'library_store.dart';

enum RepeatMode { off, all, one }

class MusicController extends ChangeNotifier {
  MusicController({
    AudiusService? api,
    MusicCatalog? catalog,
    LibraryStore? library,
  })  : api = api ?? AudiusService(),
        catalog = catalog ?? MusicCatalog(),
        library = library ?? LibraryStore() {
    this.library.load();
    player.playerStateStream.listen((s) {
      if (autoAdvance && s.processingState == ProcessingState.completed) {
        _onCompleted();
      }
      notifyListeners();
    });
  }

  final AudiusService api;
  final MusicCatalog catalog;
  final LibraryStore library;
  final AudioPlayer player = AudioPlayer();
  final _rng = Random();

  // Fila: _queue guarda as faixas; _order é a ordem de reprodução (índices da fila).
  List<Track> _queue = [];
  List<int> _order = [];
  int _pos = -1;

  bool loading = false;
  String? error;

  /// Os jogos desligam isso enquanto usam o player, pra não pular a fila.
  bool autoAdvance = true;

  bool shuffle = false;
  RepeatMode repeat = RepeatMode.off;

  /// Quando a fila acaba, continua com músicas parecidas.
  bool autoplay = true;

  Timer? _sleepTimer;
  DateTime? sleepEndsAt;
  bool _advancing = false;

  Track? get current =>
      (_pos >= 0 && _pos < _order.length) ? _queue[_order[_pos]] : null;

  List<Track> get upcoming => (_pos < 0 || _pos >= _order.length)
      ? <Track>[]
      : _order.skip(_pos + 1).map((i) => _queue[i]).toList();

  bool get isPlaying => player.playing;
  Stream<Duration> get positionStream => player.positionStream;
  Duration? get duration => player.duration;

  // ---------- Montagem da fonte de áudio ----------

  /// Monta a fonte de áudio da faixa. [tag] é o que aparece na notificação.
  AudioSource audioSourceFor(Track t, {MediaItem? tag}) {
    final isAudius = t.source == 'audius';
    return AudioSource.uri(
      Uri.parse(t.directUrl ?? api.streamUrl(t.id)),
      // A chave do Audius só vai para o Audius, nunca para outros sites.
      headers: isAudius ? api.headers : null,
      tag: tag ??
          MediaItem(
            id: t.id,
            title: t.title,
            artist: t.artist,
            artUri: t.artworkUrl != null ? Uri.parse(t.artworkUrl!) : null,
          ),
    );
  }

  // ---------- Começar a tocar ----------

  /// Define a fila e começa a tocar em [startIndex].
  Future<void> playQueue(List<Track> tracks, int startIndex) async {
    if (tracks.isEmpty) return;
    _queue = List.of(tracks); // cópia: a fila pode crescer com a reprodução automática
    final s = startIndex < 0
        ? 0
        : (startIndex >= tracks.length ? tracks.length - 1 : startIndex);
    _buildOrder(s);
    await _playPos(_pos);
  }

  /// Toca a lista toda em ordem aleatória.
  Future<void> playShuffled(List<Track> tracks) async {
    if (tracks.isEmpty) return;
    shuffle = true;
    await playQueue(tracks, _rng.nextInt(tracks.length));
  }

  void _buildOrder(int start) {
    _order = List.generate(_queue.length, (i) => i);
    if (shuffle) {
      _order.remove(start);
      _order.shuffle(_rng);
      _order.insert(0, start);
      _pos = 0;
    } else {
      _pos = start;
    }
  }

  Future<void> _playPos(int pos, {int attempts = 0}) async {
    if (pos < 0 || pos >= _order.length) return;
    _pos = pos;
    error = null;
    loading = true;
    notifyListeners();

    final t = _queue[_order[_pos]];
    try {
      await player.setAudioSource(audioSourceFor(t));
      loading = false;
      library.addToHistory(t);
      notifyListeners();
      player.play();
    } catch (_) {
      // Faixa indisponível: pula para a próxima (até 5 seguidas).
      if (attempts < 5 && _order.length > 1) {
        if (await _advance(attempts: attempts + 1)) return;
      }
      loading = false;
      error = 'Não foi possível tocar "${t.title}".';
      notifyListeners();
    }
  }

  /// Vai para a próxima faixa. Devolve false se não havia próxima.
  Future<bool> _advance({int attempts = 0}) async {
    if (_order.isEmpty) return false;
    var nextPos = _pos + 1;
    if (nextPos >= _order.length) {
      if (repeat == RepeatMode.all) {
        if (shuffle) _order.shuffle(_rng);
        nextPos = 0;
      } else if (autoplay && await _loadMoreAutoplay()) {
        nextPos = _pos + 1;
      } else {
        return false;
      }
    }
    await _playPos(nextPos, attempts: attempts);
    return true;
  }

  /// Reprodução automática: busca músicas do mesmo artista e, se faltar, as mais ouvidas.
  Future<bool> _loadMoreAutoplay() async {
    final seed = current;
    if (seed == null) return false;
    try {
      final known = _queue.map((t) => t.id).toSet();
      final more = <Track>[];

      void addNew(List<Track> list) {
        for (final t in list) {
          if (known.add(t.id)) more.add(t);
        }
      }

      addNew(await catalog.search(seed.artist));
      if (more.length < 5) addNew(await catalog.trending());
      if (more.isEmpty) return false;

      final start = _queue.length;
      _queue.addAll(more.take(30));
      for (var i = start; i < _queue.length; i++) {
        _order.add(i);
      }
      return true;
    } catch (_) {
      return false;
    }
  }

  Future<void> _onCompleted() async {
    if (_advancing) return;
    _advancing = true;
    try {
      if (repeat == RepeatMode.one) {
        await player.seek(Duration.zero);
        player.play();
      } else if (!await _advance()) {
        // Fila acabou e não há mais o que tocar.
        await player.pause();
        await player.seek(Duration.zero);
      }
    } finally {
      _advancing = false;
      notifyListeners();
    }
  }

  // ---------- Controles ----------

  Future<void> next() async {
    await _advance();
  }

  Future<void> previous() async {
    // Se já passou de 3s (ou é a primeira), volta pro começo da faixa.
    if (player.position > const Duration(seconds: 3) || _pos <= 0) {
      await player.seek(Duration.zero);
      return;
    }
    await _playPos(_pos - 1);
  }

  Future<void> togglePlay() async {
    if (player.playing) {
      await player.pause();
    } else {
      player.play();
    }
    notifyListeners();
  }

  Future<void> seek(Duration position) => player.seek(position);

  void toggleShuffle() {
    shuffle = !shuffle;
    if (_pos >= 0 && _pos < _order.length) {
      _buildOrder(_order[_pos]);
    }
    notifyListeners();
  }

  void cycleRepeat() {
    repeat = RepeatMode.values[(repeat.index + 1) % RepeatMode.values.length];
    notifyListeners();
  }

  void toggleAutoplay() {
    autoplay = !autoplay;
    notifyListeners();
  }

  // ---------- Fila ----------

  Future<void> playNext(Track t) async {
    if (current == null) {
      await playQueue([t], 0);
      return;
    }
    _queue.add(t);
    _order.insert(_pos + 1, _queue.length - 1);
    notifyListeners();
  }

  Future<void> addToQueue(Track t) async {
    if (current == null) {
      await playQueue([t], 0);
      return;
    }
    _queue.add(t);
    _order.add(_queue.length - 1);
    notifyListeners();
  }

  /// Pula direto para a k-ésima faixa da lista "A seguir".
  Future<void> jumpToUpcoming(int k) => _playPos(_pos + 1 + k);

  // ---------- Timer para dormir ----------

  void setSleepTimer(Duration? d) {
    _sleepTimer?.cancel();
    _sleepTimer = null;
    sleepEndsAt = null;
    if (d != null) {
      sleepEndsAt = DateTime.now().add(d);
      _sleepTimer = Timer(d, () {
        player.pause();
        sleepEndsAt = null;
        notifyListeners();
      });
    }
    notifyListeners();
  }

  @override
  void dispose() {
    _sleepTimer?.cancel();
    player.dispose();
    super.dispose();
  }
}

// ======================================================================
// MiniPlayer: barra "tocando agora". Coloque acima da barra de navegação.
// Ao tocar nela, abre o player grande (passe onTap: () => openPlayer(context, music)).
// ======================================================================

const _neon = Color(0xFF39FF14);

class MiniPlayer extends StatelessWidget {
  const MiniPlayer({super.key, required this.controller, this.onTap});

  final MusicController controller;
  final VoidCallback? onTap;

  Widget _cover(Track t) {
    const fallback = Icon(Icons.music_note, color: Colors.white54);
    final url = t.artworkUrl;
    if (url == null || url.isEmpty) return fallback;
    return ClipRRect(
      borderRadius: BorderRadius.circular(6),
      child: Image.network(
        url,
        width: 44,
        height: 44,
        fit: BoxFit.cover,
        errorBuilder: (_, __, ___) => fallback,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: controller,
      builder: (context, _) {
        final t = controller.current;
        if (t == null) return const SizedBox.shrink();

        return Material(
          color: const Color(0xFF15151E),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              StreamBuilder<Duration>(
                stream: controller.positionStream,
                builder: (context, snap) {
                  final pos = snap.data?.inMilliseconds ?? 0;
                  final dur = controller.duration?.inMilliseconds ?? 0;
                  return LinearProgressIndicator(
                    value: dur > 0 ? (pos / dur).clamp(0.0, 1.0).toDouble() : 0,
                    minHeight: 2,
                    color: _neon,
                    backgroundColor: Colors.white12,
                  );
                },
              ),
              ListTile(
                dense: true,
                onTap: onTap,
                leading: SizedBox(width: 44, height: 44, child: _cover(t)),
                title: Text(t.title,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(color: Colors.white)),
                subtitle: Text(controller.error ?? t.artist,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                        color: controller.error != null
                            ? Colors.redAccent
                            : Colors.white60)),
                trailing: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    IconButton(
                      color: Colors.white,
                      onPressed: controller.previous,
                      icon: const Icon(Icons.skip_previous),
                    ),
                    controller.loading
                        ? const Padding(
                            padding: EdgeInsets.all(12),
                            child: SizedBox(
                              width: 22,
                              height: 22,
                              child: CircularProgressIndicator(
                                  strokeWidth: 2, color: _neon),
                            ),
                          )
                        : IconButton(
                            color: _neon,
                            onPressed: controller.togglePlay,
                            icon: Icon(controller.isPlaying
                                ? Icons.pause_circle_filled
                                : Icons.play_circle_filled),
                            iconSize: 36,
                          ),
                    IconButton(
                      color: Colors.white,
                      onPressed: controller.next,
                      icon: const Icon(Icons.skip_next),
                    ),
                  ],
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}
