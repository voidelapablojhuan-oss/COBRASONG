// lib/widgets/ui_common.dart
// Peças visuais usadas em várias telas.

import 'package:flutter/material.dart';
import '../services/audius_service.dart';
import '../services/music_controller.dart';

const kBg = Color(0xFF0B0B0F);
const kPurple = Color(0xFF7C3AED);
const kNeon = Color(0xFF39FF14);
const kCard = Color(0xFF15151E);

const _white = TextStyle(color: Colors.white);
const _white60 = TextStyle(color: Colors.white60);

class TrackCover extends StatelessWidget {
  const TrackCover({
    super.key,
    required this.track,
    this.size = 48,
    this.radius = 6,
  });

  final Track track;
  final double size;
  final double radius;

  @override
  Widget build(BuildContext context) {
    final fallback = Container(
      width: size,
      height: size,
      color: kCard,
      child: Icon(Icons.music_note, color: Colors.white54, size: size / 2),
    );
    final url = track.artworkUrl;
    return ClipRRect(
      borderRadius: BorderRadius.circular(radius),
      child: (url == null || url.isEmpty)
          ? fallback
          : Image.network(
              url,
              width: size,
              height: size,
              fit: BoxFit.cover,
              errorBuilder: (_, __, ___) => fallback,
            ),
    );
  }
}

/// Item de música: toque pra tocar, coração pra favoritar, menu com mais ações.
class TrackTile extends StatelessWidget {
  const TrackTile({
    super.key,
    required this.controller,
    required this.track,
    required this.onTap,
  });

  final MusicController controller;
  final Track track;
  final VoidCallback onTap;

  void _snack(BuildContext context, String msg) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(msg), duration: const Duration(seconds: 2)),
    );
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: controller.library,
      builder: (context, _) {
        final fav = controller.library.isFavorite(track.id);
        return ListTile(
          onTap: onTap,
          leading: TrackCover(track: track),
          title: Text(track.title,
              maxLines: 1, overflow: TextOverflow.ellipsis, style: _white),
          subtitle: Text(track.artist,
              maxLines: 1, overflow: TextOverflow.ellipsis, style: _white60),
          trailing: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              IconButton(
                tooltip: fav ? 'Remover dos favoritos' : 'Favoritar',
                icon: Icon(fav ? Icons.favorite : Icons.favorite_border,
                    color: fav ? kNeon : Colors.white54),
                onPressed: () => controller.library.toggleFavorite(track),
              ),
              PopupMenuButton<String>(
                color: kCard,
                icon: const Icon(Icons.more_vert, color: Colors.white70),
                onSelected: (v) {
                  switch (v) {
                    case 'next':
                      controller.playNext(track);
                      _snack(context, 'Vai tocar a seguir');
                      break;
                    case 'queue':
                      controller.addToQueue(track);
                      _snack(context, 'Adicionada à fila');
                      break;
                    case 'playlist':
                      showAddToPlaylistSheet(context, controller, track);
                      break;
                  }
                },
                itemBuilder: (_) => const [
                  PopupMenuItem(
                      value: 'next', child: Text('Tocar a seguir', style: _white)),
                  PopupMenuItem(
                      value: 'queue',
                      child: Text('Adicionar à fila', style: _white)),
                  PopupMenuItem(
                      value: 'playlist',
                      child: Text('Adicionar à playlist', style: _white)),
                ],
              ),
            ],
          ),
        );
      },
    );
  }
}

/// Botões "Tocar tudo" e "Aleatório" para uma lista de músicas.
class PlayButtons extends StatelessWidget {
  const PlayButtons({super.key, required this.controller, required this.tracks});

  final MusicController controller;
  final List<Track> tracks;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 8),
      child: Row(
        children: [
          Expanded(
            child: FilledButton.icon(
              style: FilledButton.styleFrom(backgroundColor: kPurple),
              onPressed: tracks.isEmpty
                  ? null
                  : () => controller.playQueue(tracks, 0),
              icon: const Icon(Icons.play_arrow),
              label: const Text('Tocar tudo'),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: OutlinedButton.icon(
              style: OutlinedButton.styleFrom(
                foregroundColor: kNeon,
                side: const BorderSide(color: kNeon),
              ),
              onPressed:
                  tracks.isEmpty ? null : () => controller.playShuffled(tracks),
              icon: const Icon(Icons.shuffle),
              label: const Text('Aleatório'),
            ),
          ),
        ],
      ),
    );
  }
}

/// Pede um texto ao usuário (ex.: nome da playlist). Devolve null se cancelar.
Future<String?> promptText(BuildContext context, String title) async {
  final ctrl = TextEditingController();
  final result = await showDialog<String>(
    context: context,
    builder: (ctx) => AlertDialog(
      backgroundColor: kCard,
      title: Text(title, style: _white),
      content: TextField(
        controller: ctrl,
        autofocus: true,
        style: _white,
        decoration: const InputDecoration(
          hintText: 'Digite aqui',
          hintStyle: TextStyle(color: Colors.white38),
        ),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(ctx),
          child: const Text('Cancelar'),
        ),
        FilledButton(
          style: FilledButton.styleFrom(backgroundColor: kPurple),
          onPressed: () => Navigator.pop(ctx, ctrl.text.trim()),
          child: const Text('OK'),
        ),
      ],
    ),
  );
  return (result == null || result.isEmpty) ? null : result;
}

/// Lista de playlists para escolher onde guardar a música (ou criar uma nova).
Future<void> showAddToPlaylistSheet(
    BuildContext context, MusicController c, Track t) {
  return showModalBottomSheet<void>(
    context: context,
    backgroundColor: kCard,
    builder: (ctx) => ListenableBuilder(
      listenable: c.library,
      builder: (ctx, _) {
        final lists = c.library.playlists;
        return SafeArea(
          child: ListView(
            shrinkWrap: true,
            children: [
              ListTile(
                leading: const Icon(Icons.add, color: kNeon),
                title: const Text('Nova playlist', style: _white),
                onTap: () async {
                  final name = await promptText(ctx, 'Nome da playlist');
                  if (name == null) return;
                  final i = c.library.createPlaylist(name);
                  c.library.addToPlaylist(i, t);
                  if (ctx.mounted) Navigator.pop(ctx);
                },
              ),
              for (var i = 0; i < lists.length; i++)
                ListTile(
                  leading: const Icon(Icons.queue_music, color: Colors.white70),
                  title: Text(lists[i].name, style: _white),
                  subtitle: Text('${lists[i].tracks.length} músicas',
                      style: _white60),
                  onTap: () {
                    c.library.addToPlaylist(i, t);
                    Navigator.pop(ctx);
                  },
                ),
            ],
          ),
        );
      },
    ),
  );
}
