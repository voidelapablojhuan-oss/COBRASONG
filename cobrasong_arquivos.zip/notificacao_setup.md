# Notificação de música (COBRASONG)

Sem isso o Android não mostra nada enquanto a música toca.

## 1. pubspec.yaml

```yaml
dependencies:
  just_audio: ^0.9.40
  just_audio_background: ^0.0.1-beta.15
  http: ^1.2.0
  shared_preferences: ^2.2.0
```

## 2. lib/main.dart

```dart
import 'package:flutter/material.dart';
import 'package:just_audio_background/just_audio_background.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await JustAudioBackground.init(
    androidNotificationChannelId: 'com.cobrasong.app.audio',
    androidNotificationChannelName: 'COBRASONG',
    androidNotificationOngoing: true,
  );
  runApp(const SeuApp()); // mantenha o runApp que você já tem
}
```

## 3. android/app/src/main/AndroidManifest.xml

No topo do `<manifest ...>` garanta o namespace `tools` e as permissões:

```xml
<manifest xmlns:android="http://schemas.android.com/apk/res/android"
    xmlns:tools="http://schemas.android.com/tools">

    <uses-permission android:name="android.permission.INTERNET"/>
    <uses-permission android:name="android.permission.WAKE_LOCK"/>
    <uses-permission android:name="android.permission.FOREGROUND_SERVICE"/>
    <uses-permission android:name="android.permission.FOREGROUND_SERVICE_MEDIA_PLAYBACK"/>
    <uses-permission android:name="android.permission.POST_NOTIFICATIONS"/>
```

Dentro de `<application ...>`:

1. No `<activity>` que já existe, troque o `android:name`:

```xml
<activity android:name="com.ryanheise.audioservice.AudioServiceActivity" ...>
```

(troque só o valor de `android:name`; o resto da activity fica igual)

2. Adicione, ainda dentro de `<application>`, depois da activity:

```xml
<service android:name="com.ryanheise.audioservice.AudioService"
    android:foregroundServiceType="mediaPlayback"
    android:exported="true" tools:ignore="Instantiatable">
  <intent-filter>
    <action android:name="android.media.browse.MediaBrowserService" />
  </intent-filter>
</service>

<receiver android:name="com.ryanheise.audioservice.MediaButtonReceiver"
    android:exported="true" tools:ignore="Instantiatable">
  <intent-filter>
    <action android:name="android.intent.action.MEDIA_BUTTON" />
  </intent-filter>
</receiver>
```

## 4. Se ainda não aparecer (Android 13 ou mais novo)

Configurações do celular > Apps > COBRASONG > Notificações > permitir.

## 5. iOS (só se for compilar pra iPhone)

No `ios/Runner/Info.plist`:

```xml
<key>UIBackgroundModes</key>
<array>
  <string>audio</string>
</array>
```

## 6. Chaves das APIs no GitHub Actions (o APK gerado lá precisa delas)

1. No repositório: Settings > Secrets and variables > Actions > New repository secret.
   Crie dois secrets: `AUDIUS_API_KEY` e `JAMENDO_CLIENT_ID`.
2. No arquivo do workflow (pasta `.github/workflows/`), ache o passo que gera o APK
   (algo como `flutter build apk --debug`) e troque por:

```yaml
- name: Build APK
  run: >
    flutter build apk --debug
    --dart-define=AUDIUS_API_KEY=${{ secrets.AUDIUS_API_KEY }}
    --dart-define=JAMENDO_CLIENT_ID=${{ secrets.JAMENDO_CLIENT_ID }}
```

Sem isso, as músicas não carregam no APK, porque as chaves não entram no app.
Obs.: o APK é um arquivo que seus amigos instalam; quem abrir o APK com uma ferramenta
consegue ver as chaves dentro dele. Como o app é só entre amigos isso é aceitável,
mas não compartilhe o APK publicamente.

## 7. AndroidManifest

O arquivo `AndroidManifest.modelo.xml` (na raiz do zip) é um modelo pronto do passo 3.
Compare com o seu antes de substituir: mantenha o seu `android:label` e o seu ícone.
